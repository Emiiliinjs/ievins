// main.js - Common JavaScript functionality for the Zero Trust Security System

document.addEventListener('DOMContentLoaded', function() {
    // Initialize Feather icons if not already initialized
    if (typeof feather !== 'undefined') {
        feather.replace();
    }
    
    // Enable Bootstrap tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Set up session timeout warning
    setupSessionTimeout();
    
    // Setup password strength meter for password fields
    setupPasswordStrengthMeter();
    
    // Add CSRF token to AJAX requests if using Flask
    setupCSRFToken();
});

/**
 * Setup session timeout warning
 * Alerts user before their session expires
 */
function setupSessionTimeout() {
    // Session timeout in milliseconds (25 minutes, warning at 5 minutes before expiry)
    const sessionTimeout = 25 * 60 * 1000;
    const warningTime = 5 * 60 * 1000;
    
    // Check if user is logged in (has user_id in session)
    const isLoggedIn = document.body.classList.contains('logged-in') || 
                       document.querySelector('[data-user-authenticated="true"]') !== null;
    
    if (isLoggedIn) {
        // Set timeout to show warning
        setTimeout(function() {
            showSessionWarning();
        }, sessionTimeout - warningTime);
    }
}

/**
 * Show session expiry warning
 */
function showSessionWarning() {
    // Create warning modal if it doesn't exist
    if (!document.getElementById('session-warning-modal')) {
        const modalHtml = `
            <div class="modal fade" id="session-warning-modal" tabindex="-1" aria-labelledby="sessionWarningModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header bg-warning text-dark">
                            <h5 class="modal-title" id="sessionWarningModalLabel">
                                <i data-feather="clock" class="me-2"></i>Session Expiring
                            </h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <p>Your session is about to expire due to inactivity. You will be logged out in <strong><span id="session-countdown">5:00</span></strong>.</p>
                            <p>Do you want to stay logged in?</p>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Log out</button>
                            <button type="button" class="btn btn-primary" id="extend-session-btn">Stay logged in</button>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        // Append modal to body
        const modalContainer = document.createElement('div');
        modalContainer.innerHTML = modalHtml;
        document.body.appendChild(modalContainer);
        
        // Initialize feather icons in the modal
        if (typeof feather !== 'undefined') {
            feather.replace();
        }
        
        // Set up extend session button
        document.getElementById('extend-session-btn').addEventListener('click', function() {
            extendSession();
            const modal = bootstrap.Modal.getInstance(document.getElementById('session-warning-modal'));
            modal.hide();
        });
    }
    
    // Show the modal
    const sessionWarningModal = new bootstrap.Modal(document.getElementById('session-warning-modal'));
    sessionWarningModal.show();
    
    // Start countdown
    let timeLeft = 5 * 60; // 5 minutes in seconds
    const countdownElement = document.getElementById('session-countdown');
    const countdownInterval = setInterval(function() {
        const minutes = Math.floor(timeLeft / 60);
        const seconds = timeLeft % 60;
        countdownElement.textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;
        
        if (timeLeft <= 0) {
            clearInterval(countdownInterval);
            window.location.href = '/logout'; // Redirect to logout
        }
        
        timeLeft--;
    }, 1000);
}

/**
 * Extend the user's session
 */
function extendSession() {
    // Make a request to a keep-alive endpoint
    fetch('/api/keep-alive', {
        method: 'POST',
        credentials: 'same-origin',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': getCSRFToken()
        }
    })
    .then(response => {
        if (!response.ok) {
            console.error('Failed to extend session');
        }
    })
    .catch(error => {
        console.error('Error extending session:', error);
    });
}

/**
 * Setup password strength meter for password fields
 */
function setupPasswordStrengthMeter() {
    // Find password fields that need strength meter
    const passwordFields = document.querySelectorAll('input[type="password"][data-strength-meter="true"]');
    
    passwordFields.forEach(field => {
        // Create strength meter element
        const strengthMeter = document.createElement('div');
        strengthMeter.className = 'password-strength-meter mt-2';
        strengthMeter.innerHTML = `
            <div class="progress" style="height: 5px;">
                <div class="progress-bar" role="progressbar" style="width: 0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
            </div>
            <small class="form-text mt-1">Password strength: <span class="strength-text">None</span></small>
        `;
        
        // Insert after password field
        field.parentNode.insertBefore(strengthMeter, field.nextSibling);
        
        // Get progress bar and text elements
        const progressBar = strengthMeter.querySelector('.progress-bar');
        const strengthText = strengthMeter.querySelector('.strength-text');
        
        // Add input event listener
        field.addEventListener('input', function() {
            const password = this.value;
            const strength = calculatePasswordStrength(password);
            
            // Update progress bar
            progressBar.style.width = `${strength.score * 25}%`;
            progressBar.setAttribute('aria-valuenow', strength.score * 25);
            
            // Update color based on strength
            progressBar.className = 'progress-bar';
            if (strength.score === 0) {
                progressBar.classList.add('bg-danger');
            } else if (strength.score === 1) {
                progressBar.classList.add('bg-danger');
            } else if (strength.score === 2) {
                progressBar.classList.add('bg-warning');
            } else if (strength.score === 3) {
                progressBar.classList.add('bg-info');
            } else {
                progressBar.classList.add('bg-success');
            }
            
            // Update text
            strengthText.textContent = strength.message;
        });
    });
}

/**
 * Calculate password strength
 * @param {string} password - The password to check
 * @returns {Object} An object with score (0-4) and message
 */
function calculatePasswordStrength(password) {
    if (!password) {
        return { score: 0, message: 'None' };
    }
    
    let score = 0;
    const messages = ['Very Weak', 'Weak', 'Fair', 'Good', 'Strong'];
    
    // Length check
    if (password.length >= 10) score++;
    if (password.length >= 12) score++;
    
    // Complexity checks
    if (/[A-Z]/.test(password) && /[a-z]/.test(password)) score++;
    if (/\d/.test(password)) score++;
    if (/[!@#$%^&*(),.?":{}|<>]/.test(password)) score++;
    
    // Pattern checks
    if (/(.)\1\1/.test(password)) score--; // Repeated characters
    if (/^(password|admin|user|123)/i.test(password)) score--; // Common patterns
    
    // Ensure score is within bounds
    score = Math.max(0, Math.min(4, score));
    
    return {
        score: score,
        message: messages[score]
    };
}

/**
 * Setup CSRF token for AJAX requests
 */
function setupCSRFToken() {
    // Add CSRF token to AJAX requests if using Flask
    const csrfToken = getCSRFToken();
    
    if (csrfToken) {
        // Set up AJAX requests to include CSRF token
        (function() {
            const originalFetch = window.fetch;
            window.fetch = function() {
                const args = Array.from(arguments);
                const [url, options] = args;
                
                // Only add CSRF token to same-origin POST, PUT, DELETE requests
                if (options && ['POST', 'PUT', 'DELETE'].includes(options.method) && isSameOrigin(url)) {
                    options.headers = options.headers || {};
                    options.headers['X-CSRFToken'] = csrfToken;
                    args[1] = options;
                }
                
                return originalFetch.apply(this, args);
            };
        })();
    }
}

/**
 * Get CSRF token from meta tag or cookie
 * @returns {string|null} CSRF token or null if not found
 */
function getCSRFToken() {
    // First try to get token from meta tag
    const meta = document.querySelector('meta[name="csrf-token"]');
    if (meta) {
        return meta.getAttribute('content');
    }
    
    // Fallback to cookie
    const cookieValue = document.cookie
        .split('; ')
        .find(row => row.startsWith('csrf_token='));
        
    if (cookieValue) {
        return cookieValue.split('=')[1];
    }
    
    return null;
}

/**
 * Check if URL is same origin
 * @param {string} url - URL to check
 * @returns {boolean} True if URL is same origin
 */
function isSameOrigin(url) {
    try {
        const currentOrigin = window.location.origin;
        const urlObj = new URL(url, currentOrigin);
        return urlObj.origin === currentOrigin;
    } catch (e) {
        return true; // Relative URLs are same origin
    }
}

/**
 * Show a toast notification
 * @param {string} message - Message to display
 * @param {string} type - Bootstrap alert type (success, danger, warning, info)
 * @param {number} duration - Duration in milliseconds
 */
function showToast(message, type = 'info', duration = 3000) {
    // Create toast container if it doesn't exist
    let toastContainer = document.querySelector('.toast-container');
    if (!toastContainer) {
        toastContainer = document.createElement('div');
        toastContainer.className = 'toast-container position-fixed bottom-0 end-0 p-3';
        document.body.appendChild(toastContainer);
    }
    
    // Create toast element
    const toastId = `toast-${Date.now()}`;
    const toast = document.createElement('div');
    toast.className = `toast align-items-center text-white bg-${type} border-0`;
    toast.setAttribute('role', 'alert');
    toast.setAttribute('aria-live', 'assertive');
    toast.setAttribute('aria-atomic', 'true');
    toast.setAttribute('id', toastId);
    
    toast.innerHTML = `
        <div class="d-flex">
            <div class="toast-body">
                ${message}
            </div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
    `;
    
    // Add toast to container
    toastContainer.appendChild(toast);
    
    // Initialize and show toast
    const bsToast = new bootstrap.Toast(toast, {
        autohide: true,
        delay: duration
    });
    bsToast.show();
    
    // Remove toast from DOM after it's hidden
    toast.addEventListener('hidden.bs.toast', function() {
        this.remove();
    });
}
